import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { UserModel } from 'src/app/models/usermodel';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppService } from 'src/app/app.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  errorMessage: string = '';
  form: FormGroup;
  userModel: UserModel;
  submitted = false;
  otpCountMessage: string = '';
  isOTPExists: boolean = false;
  headerMessage: string = "Register to Vande Bharatham with below details";
  isMaxCount: boolean = false;
  isotpValid: boolean = false;
  isResent: boolean = false;
  isSuccess: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router,
    private httpClient: HttpClient,
    private appService: AppService) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      name: ['', Validators.required],
      phoneNo: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      wardNo: ['', Validators.required],
      profession: ['', Validators.required],
      role: ['Select Type', Validators.required],
      password: ['', Validators.required],
      otp: ['', [Validators.required, Validators.maxLength(4)]],
    });
    this.Cancel();
  }
  get f() { return this.form.controls; }

  onSubmit() {
    var isValid = false;
    this.isResent = false;
    this.otpCountMessage = '';
    var name = this.form.get('name').value;
    var wardNo = this.form.get('wardNo').value;
    var profession = this.form.get('profession').value;
    var type = this.form.get('role').value;
    var phoneNo = this.form.get('phoneNo').value;
    var password = this.form.get('password').value;
    var otp = this.form.get('otp').value;

    if (name != null && name != "" && wardNo != null && wardNo != "" && profession != null && profession != "" && type != null && type != ""
      && phoneNo != null && phoneNo != "" && password != null && password != "" && (otp == null || otp == "")) {
      isValid = true;
    }
    else {
      isValid = false;
    }
    if (isValid) {
      this.CreateUserService(this.form.value).subscribe((resuser) => {
        var result = <any>resuser;
        if (result.return_code > 0)
          this.errorMessage = result.message;
        else {
          this.isOTPExists = true;
          this.submitted = true;
          this.isMaxCount = false;
          this.ToggleHeaderMessage();
          this.errorMessage = '';
        }
      });
    }
    else {
      this.appService.validateAllFormFields(this.form);
    }
  }

  submitOTP() {
    this.isSuccess = false;
    if (this.form.get('otp').value == null)
      this.isotpValid = false;
    else
      this.isotpValid = true;

    if (this.form.valid) {
      this.VerifyOTPService().subscribe((resotp) => {
        var result = <any>resotp;
        if (result.return_code == 0) {
          this.isSuccess = true;
        }
        else {

        }
      });
    }
    else {
      this.appService.validateAllFormFields(this.form);
    }
  }

  redirectToLogin() {
    this.router.navigate(['/login']);
  }

  resend() {
    this.isResent = false;
    this.otpCountMessage = '';
    if (this.appService.OTPCount >= 1) {
      this.isResent = true;
      this.appService.OTPCount = this.appService.OTPCount - 1;
      this.isMaxCount = false;
      if (this.appService.OTPCount > 0)
        this.otpCountMessage = 'OTP has been resent. (You are left with ' + this.appService.OTPCount + ' attempts)';
      else
        this.otpCountMessage = 'OTP has been resent. (This is your last attempt)';
    }
    else {
      this.isResent = false;
      this.isMaxCount = true;
      this.otpCountMessage = '';
      this.Cancel();
    }
    this.ResendOTPService().subscribe((resResend) => {
      var result = <any>resResend;
    });
  }

  public CreateUserService(user: UserModel) {
    var endpoint = environment.endPoint + 'user/register';
    return this.httpClient.post(endpoint, user, this.appService.headers);
  }

  public VerifyOTPService() {
    var otpValue = this.form.get("otp").value;
    var phoneNoValue = this.form.get("phoneNo").value;
    var obj = {
      otp: otpValue,
      phoneNo: phoneNoValue
    };
    var endpoint = environment.endPoint + 'user/verify';
    return this.httpClient.post(endpoint, obj, this.appService.headers);
  }

  public ResendOTPService() {
    var phoneNoValue = this.form.get("phoneNo").value;
    var obj = {
      phoneNo: phoneNoValue
    };
    var endpoint = environment.endPoint + 'user/resendotp';
    return this.httpClient.post(endpoint, obj, this.appService.headers);
  }

  public ToggleHeaderMessage() {
    if (this.isOTPExists == false)
      this.headerMessage = "Register to Vande Bharatham with below details";
    else if (this.isOTPExists == true)
      this.headerMessage = "An OTP is sent to your registered number/email id. Please enter.";
  }

  Cancel() {
    this.submitted = false;
    this.appService.OTPCount = 3;
    this.isMaxCount = true;
    this.isOTPExists = false;
    this.isotpValid = true;
    this.ToggleHeaderMessage();
    this.form.reset();
    this.isResent = false;
    this.otpCountMessage = '';
    this.isSuccess = false;
    this.errorMessage = '';
  }


  back() {
    this.isSuccess = false;
    this.otpCountMessage = '';
    this.appService.OTPCount = 3;
    this.isMaxCount = true;
    this.isOTPExists = false;
    this.ToggleHeaderMessage();
    this.form.get('otp').setValue("");
    this.form.get('password').setValue("");
    this.isResent = false;
    this.errorMessage = '';
  }
}

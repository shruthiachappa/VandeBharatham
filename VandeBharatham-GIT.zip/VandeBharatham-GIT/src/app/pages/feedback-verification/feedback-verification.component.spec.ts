import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackVerificationComponent } from './feedback-verification.component';

describe('FeedbackVerificationComponent', () => {
  let component: FeedbackVerificationComponent;
  let fixture: ComponentFixture<FeedbackVerificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeedbackVerificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

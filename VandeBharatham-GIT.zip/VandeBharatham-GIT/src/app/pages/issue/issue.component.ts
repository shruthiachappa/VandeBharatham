import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AppService } from 'src/app/app.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { UserModel } from 'src/app/models/usermodel';
import { Responsibility } from 'src/app/models/responsibility';

@Component({
  selector: 'app-issue',
  templateUrl: './issue.component.html',
  styleUrls: ['./issue.component.scss']
})
export class IssueComponent implements OnInit {
  form: FormGroup;
  issueFilters: any;
  issue: any;
  issueId: string;
  users: UserModel[];
  success: boolean = true;
  message: string = '';
  isNormalUser: boolean = false;
  submit: boolean = false;
  constructor(private formBuilder: FormBuilder,
    private httpClient: HttpClient,
    private appService: AppService, private router: Router) {
    this.issueFilters = JSON.parse(localStorage.getItem('issueFilters'));
    this.issue = JSON.parse(localStorage.getItem('issue'));
    if (this.appService.currentUserSubject.value.responsibility == Responsibility.User)
      this.isNormalUser = true;
    else
      this.isNormalUser = false;
  }

  ngOnInit() {
    this.success = true;
    this.message = '';
    this.submit = false;
    this.form = this.formBuilder.group({
      wardNo: [''],
      wardAdmin: [''],
      wardContactNo: [''],
      assignee: ['Select Assignee'],
      location: [''],
      summary: [''],
      description: ['', Validators.required],
      isAnonymous: [false],
      raiserName: [''],
      state: [''],
    });
    this.LoadIssueValues();
  }

  LoadIssueValues() {
    debugger;
    this.form.get('wardNo').setValue(this.issue.wardNo);
    this.form.get('state').setValue(this.issue.state);
    if (this.issue.assigneeName != "" && this.issue.assigneeName != null) {
      this.form.get('assignee').setValue(this.issue.assigneeName);
    }
    if (this.issue.phoneNo != "" && this.issue.phoneNo != null)
      this.form.get('raiserName').setValue(this.issue.raiserName + ' (' + this.issue.phoneNo + ')');
    else
      this.form.get('raiserName').setValue(this.issue.raiserName);
    this.GetAllUsers();
    if (this.isNormalUser) {
      this.form.get('assignee').disable();
      this.form.get('state').disable();
    }
  }

  GetAllUsers() {
    debugger;
    this.GetAllUsersByWardNoService().subscribe((resultUsers) => {
      var result = <any>resultUsers;
      this.users = result.users_data;
      console.log(this.users);
    });
  }

  SubmitIssue() {
    debugger;
    var assignee = this.form.get('assignee').value;
    var description = this.form.get('description').value;
    if ((this.isNormalUser == false && assignee != "Select Assignee" && description != null && description != '') || (this.isNormalUser == true && description != null && description != '')) {
      this.submit = true;
      this.SubmitIssueService().subscribe((resultUsers) => {
        debugger;
        var result = <any>resultUsers;
        if (result.return_code == 0) {
          this.success = true;
          this.message = '';
          this.submit = false;
          this.router.navigate(['/customer-feedback']);
        }
        else {
          this.message = result.message;
          this.success = false;
        }
      });
    }
    else {
      this.submit = false;
      this.appService.validateAllFormFields(this.form);
    }
  }

  SubmitIssueService() {
    debugger;
    var assigneeName;
    var phoneNo;
    if (!this.isNormalUser) {
      assigneeName = this.form.get('assignee').value;
      phoneNo = this.users.find(x => x.name == assigneeName).phoneNo;
    }
    else if (this.isNormalUser) {
      assigneeName = this.issue.assigneeName;
      phoneNo = this.issue.phoneNo;
    }
    else {
      assigneeName = '';
      phoneNo = '';
    }
    var obj = {
      wardNo: this.issue.wardNo,
      issueId: this.issue.issueId,
      state: this.form.get('state').value,
      assigneeName: this.form.get('assignee').value,
      assigneePhoneNo: phoneNo,
      comment: this.form.get('description').value,
      anonymousFlag: this.form.get('isAnonymous').value,
      name: this.appService.currentUserSubject.value.name,
      phoneNo: this.appService.currentUserSubject.value.phoneNo
    }
    var endpoint = environment.endPoint + 'issue/state';
    return this.httpClient.post(endpoint, obj, this.appService.headers);
  }

  public GetAllUsersByWardNoService() {
    debugger;
    var endpoint = environment.endPoint + 'user/getallusers?wardNo=' + this.form.get('wardNo').value;
    return this.httpClient.get(endpoint, this.appService.headers);
  }

  Back() {
    this.router.navigate(['/customer-feedback']);
  }
}

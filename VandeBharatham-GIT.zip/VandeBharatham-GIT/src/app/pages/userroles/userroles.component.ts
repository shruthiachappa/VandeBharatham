import { Component, OnInit } from '@angular/core';
import { UserModel } from 'src/app/models/usermodel';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppService } from 'src/app/app.service';
import { environment } from 'src/environments/environment';
import { Responsibility } from 'src/app/models/responsibility';

@Component({
  selector: 'app-userroles',
  templateUrl: './userroles.component.html',
  styleUrls: ['./userroles.component.scss']
})
export class UserrolesComponent implements OnInit {

  constructor(private httpClient: HttpClient, private appService: AppService) { }
  users: Array<UserModel> = [];
  searchString: string;
  selectedAll: any;
  isSubmit: boolean = false;
  wardNo: string = '';
  showButton: boolean = true;

  ngOnInit() {
    this.Cancel();
  }

  selectAll() {
    for (var i = 0; i < this.users.length; i++) {
      this.users[i].state = this.selectedAll;
    }
  }

  checkIfAllSelected() {
    this.selectedAll = this.users.every(function (item: any) {
      return item.selected == true;
    });
  }

  Cancel() {
    this.isSubmit = false;
    this.selectedAll = false;
    this.wardNo = '';
    this.users = [];
    this.selectAll();

    this.wardNo = this.appService.currentUserSubject.value.wardNo.toString();
    if (this.appService.currentUserSubject.value.responsibility == Responsibility.Admin) {
      this.showButton = false;     
    }
    this.ViewUsers();
  }

  RefreshAfterMarking() {
    this.selectedAll = false;
    this.selectAll();
    this.isSubmit = true;
    this.GetAllUsersByWardNoService().subscribe((resultUsers) => {
      var result = <any>resultUsers;
      this.users = result.users_data;
    });
  }

  AssignAdmins(val: string) {
    var users = [];
    this.users.forEach(element => {
      if (element.state == true) {
        var obj = {
          phoneNo: element.phoneNo,
          responsibility: val
        }
        users.push(obj);
      }
    });
    var data = {
      users: users
    }
    if (users.length > 0) {
      this.AdminService(data).subscribe((resultUsers) => {
        var result = <any>resultUsers;
        if (result.return_code == 0) {
          this.RefreshAfterMarking();
        }
        else {
          this.isSubmit = false;
        }
      });
    }
  }

  MarkWardAdmin() {
    this.AssignAdmins('ward_admin');
  }

  RemoveWardAdmin() {
    this.AssignAdmins('ward_user');
  }

  ViewUsers() {
    this.isSubmit = false;
    this.selectedAll = false;
    this.users = [];
    this.selectAll();
    this.GetAllUsersByWardNoService().subscribe((resultUsers) => {
      var result = <any>resultUsers;
      this.users = result.users_data;
    });
  }

  public GetAllUsersByWardNoService() {
    var endpoint = environment.endPoint + 'user/getallusers?wardNo=' + this.wardNo;
    return this.httpClient.get(endpoint, this.appService.headers);
  }

  public AdminService(data: any) {
    var endpoint = environment.endPoint + 'user/updateresponsibility';
    return this.httpClient.post(endpoint, data, this.appService.headers);
  }
}


import { Component, OnInit, OnDestroy, DebugElement } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from "@angular/router";
import { LoginModel } from 'src/app/models/loginmodel';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { AppService } from 'src/app/app.service';
import { BehaviorSubject } from 'rxjs';
import { UserModel } from 'src/app/models/usermodel';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  form: FormGroup;
  errorMessage: string = '';
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private httpClient: HttpClient, private appService: AppService) {
    this.appService.currentUserSubject = new BehaviorSubject<UserModel>(JSON.parse(localStorage.getItem('currentUser')));
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      phoneNo: ['', Validators.required],
      password: ['', Validators.required],
    });
    this.Cancel();
    // this.form.get('phoneNo').setValue("1010101010");
    // this.form.get('password').setValue("1010101010");
  }

  public get currentUserValue(): UserModel {
    return this.appService.currentUserSubject.value;
  }

  ngOnDestroy() {
  }

  onSubmit() {
    this.errorMessage = '';
    if (this.form.valid) {
      this.LoginService(this.form.value).subscribe((resuser) => {
        debugger;
        var result = <any>resuser;
        if (result.return_code == 0) {
          localStorage.setItem('currentUser', JSON.stringify(result.user));
          this.appService.currentUserSubject.next(result.user);
          this.router.navigate(['/user-registration']);
        }
        else {
          this.errorMessage = result.message;
        }
      });
    }
    else {
      this.appService.validateAllFormFields(this.form);
    }
  }

  Cancel() {
    this.form.reset();
    this.errorMessage = '';
  }

  public LoginService(model: LoginModel) {
    var endpoint = environment.endPoint + 'user/login';
    return this.httpClient.post(endpoint, model, this.appService.headers);
  }
}

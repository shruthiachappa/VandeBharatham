import { Routes } from '@angular/router';

import { DashboardComponent } from '../../pages/dashboard/dashboard.component';
import { IconsComponent } from '../../pages/icons/icons.component';
import { MapsComponent } from '../../pages/maps/maps.component';
import { UserProfileComponent } from '../../pages/user-profile/user-profile.component';
import { TablesComponent } from '../../pages/tables/tables.component';
import { UserRegistrationComponent } from '../../pages/user-registration/user-registration.component';
import { CustomerProfileComponent } from '../../pages/customer-profile/customer-profile.component';
import { CustomerFeedbackComponent } from '../../pages/customer-feedback/customer-feedback.component';
import { FeedbackVerificationComponent } from '../../pages/feedback-verification/feedback-verification.component';
import { UserrolesComponent } from 'src/app/pages/userroles/userroles.component';
import { LogoutComponent } from 'src/app/pages/logout/logout.component';
import { AuthGuard } from 'src/app/helpers/auth.guard';
import { Role } from 'src/app/models/role';
import { Responsibility } from 'src/app/models/responsibility';
import { IssueComponent } from 'src/app/pages/issue/issue.component';
import { LoginComponent } from 'src/app/pages/login/login.component';

export const AdminLayoutRoutes: Routes = [
    // { path: 'dashboard', component: DashboardComponent },
    // { path: 'user-profile', component: UserProfileComponent },
    // { path: 'tables', component: TablesComponent },
    // { path: 'icons', component: IconsComponent },
    //  { path: 'maps', component: MapsComponent },
    {
        path: 'user-registration',
        component: UserRegistrationComponent,
        canActivate: [AuthGuard],
        data: { roles: [Responsibility.User, Responsibility.Admin, Responsibility.Cluster] }
    },
    // { path: 'customer-profile', component: CustomerProfileComponent },
    {
        path: 'customer-feedback',
        component: CustomerFeedbackComponent,
        canActivate: [AuthGuard],
        data: { roles: [Responsibility.User, Responsibility.Admin, Responsibility.Cluster] }
    },
    //  { path: 'feedback-verification', component: FeedbackVerificationComponent },
    {
        path: 'user-roles',
        component: UserrolesComponent,
        canActivate: [AuthGuard],
        data: { roles: [Responsibility.Admin, Responsibility.Cluster] }
    },
    {
        path: 'issue',
        component: IssueComponent,
        canActivate: [AuthGuard],
        data: { roles: [Responsibility.Admin, Responsibility.Cluster, Responsibility.User] }
    },
    { path: 'logout', component: LogoutComponent }
];

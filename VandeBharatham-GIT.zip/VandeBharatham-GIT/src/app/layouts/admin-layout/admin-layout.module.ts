import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'; import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ClipboardModule } from 'ngx-clipboard';

import { AdminLayoutRoutes } from './admin-layout.routing';
import { DashboardComponent } from '../../pages/dashboard/dashboard.component';
import { IconsComponent } from '../../pages/icons/icons.component';
import { MapsComponent } from '../../pages/maps/maps.component';
import { UserProfileComponent } from '../../pages/user-profile/user-profile.component';
import { TablesComponent } from '../../pages/tables/tables.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UserRegistrationComponent } from '../../pages/user-registration/user-registration.component';
import { CustomerProfileComponent } from '../../pages/customer-profile/customer-profile.component';
import { CustomerFeedbackComponent } from '../../pages/customer-feedback/customer-feedback.component';
import { FeedbackVerificationComponent } from '../../pages/feedback-verification/feedback-verification.component';
import { UserrolesComponent } from 'src/app/pages/userroles/userroles.component';
import { SearchbyfilterPipe } from 'src/app/pipes/searchbyfilter.pipe';
import { NumbersOnlyDirective } from 'src/app/directives/numbers-only.directive';
import { LogoutComponent } from 'src/app/pages/logout/logout.component';
import { IssueComponent } from 'src/app/pages/issue/issue.component';
// import { ToastrModule } from 'ngx-toastr';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbModule,
    ClipboardModule
  ],
  declarations: [
    DashboardComponent,
    UserProfileComponent,
    UserRegistrationComponent,
    TablesComponent,
    IconsComponent,
    MapsComponent,
    CustomerProfileComponent,
    CustomerFeedbackComponent,
    FeedbackVerificationComponent,
    UserrolesComponent,
    SearchbyfilterPipe,
    LogoutComponent,
    IssueComponent
  ]
})

export class AdminLayoutModule { }

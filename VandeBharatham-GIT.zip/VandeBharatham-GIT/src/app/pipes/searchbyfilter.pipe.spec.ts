import { SearchbyfilterPipe } from './searchbyfilter.pipe';

describe('SearchbyfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchbyfilterPipe();
    expect(pipe).toBeTruthy();
  });
});

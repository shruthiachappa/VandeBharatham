export class IssueModel {
    issueId: number;
    anonymousFlag: boolean;
    assigneeName: string;
    issueSubtype: string;
    issueType: string;
    location: string;
    raiserName: string;
    state: string;
    wardNo: number;
}
export class LoginModel {
    phoneNo: Number;
    password: string;
}
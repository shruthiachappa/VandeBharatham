export enum IssueType {
    Bescom = 'Bescom',
    Cluster = 'Water',
    Traffic = 'Traffic',
    Roads = 'Roads',
    Schools = 'Schools'
}
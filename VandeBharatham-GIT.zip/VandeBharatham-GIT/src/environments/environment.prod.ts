export const environment = {
  production: true,
  endPoint: "https://gpwj334yoc.execute-api.ap-south-1.amazonaws.com/Prod/"
};
